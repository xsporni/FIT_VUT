Získáno bodů:	15 hodnotil ceskam 2018-05-21
