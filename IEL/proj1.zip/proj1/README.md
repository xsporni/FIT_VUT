Všetky obvody som vytváral na stránke https://www.draw.io/
